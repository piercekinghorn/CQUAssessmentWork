package com.bignerdranch.android.musicpro;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.SyncStateContract;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import java.io.Serializable;

public class MainActivity extends AppCompatActivity
{
    Venue mVenue;

    private static final String TAG = "PhotoGalleryFragment";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DbProvider.get(this).loadTestData();

        new FetchItemsTask().execute();
    }

    public void onVenueClick(View view)
    {
        Intent intent = new Intent(MainActivity.this, VenueListActivity.class);
        startActivity(intent);
    }

    public void onMapClick(View view)
    {
        Intent intent = new Intent (MainActivity.this, GoogleMapActivity.class);
        String name = mVenue.getName();
        System.out.println(name);
//        Bundle bundle = new Bundle();
//        bundle.putSerializable("venue",mVenue);
//        intent.putExtras(bundle);
        intent.putExtra("venue",mVenue);

        startActivity(intent);
    }

    // just for testing the map without retrieving top-rated venue
    void getTestVenue()
    {
        mVenue = new Venue();
        mVenue.setName("Reef Hotel");
        mVenue.setAddress("Wharf Street, Cairns");
        mVenue.setLat(-16.9238);
        mVenue.setLon(145.7797);
    }

    //Loads the fetched venue
    public void Adapter(Venue venue)
    {
        DbProvider.get(this).addVenue(venue);
    }

    //Fetches the venue
    private class FetchItemsTask extends AsyncTask<Void,Void,Venue>
    {
        @Override
        protected Venue doInBackground(Void... params) {
            return new VenueFetchr().fetchItems();
        }

        @Override
        protected void onPostExecute(Venue venue) {
            mVenue = venue;
           // Adapter(venue);
        }
    }
}


