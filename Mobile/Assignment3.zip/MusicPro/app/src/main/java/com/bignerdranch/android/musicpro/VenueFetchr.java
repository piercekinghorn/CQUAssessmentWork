//Author: Pierce Kinghorn
//Date: 31/05/2020
package com.bignerdranch.android.musicpro;

import android.util.Log;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;


public class VenueFetchr
{
    private static final String TAG = "VenueFetchr";

    //Checks url connection
    public byte[] getUrlBytes(String urlSpec) throws IOException
    {
        URL url = new URL(urlSpec);
        HttpURLConnection connection = (HttpURLConnection)url.openConnection();

        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            InputStream in = connection.getInputStream();

            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new IOException(connection.getResponseMessage() +
                        ": with " +
                        urlSpec);
            }

            int bytesRead = 0;
            byte[] buffer = new byte[1024];
            while ((bytesRead = in.read(buffer)) > 0) {
                out.write(buffer, 0, bytesRead);
            }
            out.close();
            return out.toByteArray();
        } finally {
            connection.disconnect();
        }
    }

    public String getUrlString(String urlSpec) throws IOException {
        return new String(getUrlBytes(urlSpec));
    }

    //fetches the venue from the url
    public Venue fetchItems() {

        Venue venue = new Venue();

        try {
            String url = "http://jellymud.com/venues/best_venue.json";
            String jsonString = getUrlString(url);

            Log.i(TAG, "Received JSON: " + jsonString);
            JSONObject jsonBody = new JSONObject(jsonString);

            parseItems(venue, jsonBody);

        } catch (IOException ioe) {
            Log.e(TAG, "Failed to fetch items", ioe);
        } catch (JSONException je){
            Log.e(TAG, "Failed to parse JSON", je);
        }

        return venue;
    }

    //parses the json and sets venue variables
    private void parseItems(Venue venue, JSONObject jsonBody)
            throws IOException, JSONException {

        JSONObject venueJsonObject = jsonBody;

        venue.setName(venueJsonObject.getString("name"));
        venue.setAddress(venueJsonObject.getString("address"));
        venue.setLat(venueJsonObject.getDouble("lat"));
        venue.setLon(venueJsonObject.getDouble("lon"));
    }
}//end class
