//Author: Pierce Kinghorn
//Date: 31/05/2020
package com.bignerdranch.android.musicpro;

import androidx.fragment.app.Fragment;
import android.app.Dialog;
import android.content.DialogInterface;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

public class GoogleMapActivity extends SingleFragmentActivity {

    private static final int REQUEST_ERROR= 0;

    @Override
    protected Fragment createFragment()
    {
        return new GoogleMapFragment();
    }

    @Override
    protected void onResume() {
        super.onResume();

        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int errorCode = apiAvailability.isGooglePlayServicesAvailable(this);

        if (errorCode != ConnectionResult.SUCCESS) {
            Dialog errorDialog = apiAvailability
                    .getErrorDialog(this, errorCode, REQUEST_ERROR,
                            new DialogInterface.OnCancelListener() {

                                @Override
                                public void onCancel(DialogInterface dialog) {
                                    // Leave if services are unavailable.
                                    finish();
                                }
                            });

            errorDialog.show();
        }
    }
}//end class
