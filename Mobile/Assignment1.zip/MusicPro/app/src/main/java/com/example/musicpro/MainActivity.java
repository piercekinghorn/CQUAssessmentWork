//Class: MainActivity
//Author: Pierce Kinghorn
//LastEdited: 12/4/2020
package com.example.musicpro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button mVenueButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Start VenueListActivity
        mVenueButton = (Button) findViewById(R.id.venue_button);
        mVenueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, VenueListActivity.class);
                startActivity(intent);
            }
        });
    }
}
