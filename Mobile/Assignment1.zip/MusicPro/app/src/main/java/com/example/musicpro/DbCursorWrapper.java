//Class: DbCursorWrapper
//Author: Pierce Kinghorn
//LastEdited: 9/4/2020
package com.example.musicpro;

import android.database.Cursor;
import android.database.CursorWrapper;
import java.util.UUID;

import com.example.musicpro.DbSchema.VenueTable;

public class DbCursorWrapper extends CursorWrapper
{
    public DbCursorWrapper(Cursor cursor)
    {
        super(cursor);
    }

    public Venue getItem()
    {
        String uuidString = getString(getColumnIndex(VenueTable.Cols.UUID));
        String name = getString(getColumnIndex(VenueTable.Cols.NAME));
        String address = getString(getColumnIndex(VenueTable.Cols.ADDRESS));
        String openingTime = getString(getColumnIndex(VenueTable.Cols.OPENING_TIME));
        Double lat = getDouble(getColumnIndex(VenueTable.Cols.LAT));
        Double lon = getDouble(getColumnIndex(VenueTable.Cols.LON));

        Venue venue = new Venue(UUID.fromString(uuidString));
        venue.setName(name);
        venue.setAddress(address);
        venue.setOpeningTime(openingTime);
        venue.setLat(lat);
        venue.setLon(lon);

        return venue;
    }
}
