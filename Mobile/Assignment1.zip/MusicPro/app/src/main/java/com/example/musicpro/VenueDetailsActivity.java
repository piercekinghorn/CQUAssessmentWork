//Class: VenueDetailsActivity
//Author: Pierce Kinghorn
//LastEdited: 9/4/2020
package com.example.musicpro;

import androidx.fragment.app.Fragment;

public class VenueDetailsActivity extends SingleFragmentActivity {

    @Override
    protected Fragment createFragment() { return new VenueDetailsFragment();
    }
}