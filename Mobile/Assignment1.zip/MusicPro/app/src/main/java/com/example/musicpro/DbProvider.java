//Class: DbProvider
//Author: Pierce Kinghorn
//LastEdited: 9/4/2020
package com.example.musicpro;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.musicpro.DbSchema.VenueTable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class DbProvider
{
    private static DbProvider sDbAdapter;

    private Context mContext;
    private SQLiteDatabase mDatabase;

    public static DbProvider get(Context context)
    {
        if (sDbAdapter == null)
        {
            sDbAdapter = new DbProvider(context);
        }
        return sDbAdapter;
    }

    private DbProvider(Context context)
    {
        mContext = context.getApplicationContext();
        mDatabase = new DbHelper(mContext).getWritableDatabase();
    }

    //Get venue from list
    public List<Venue> getVenues()
    {
        List<Venue> venues = new ArrayList<>();

        DbCursorWrapper cursor = runQuery(null, null);

        try
        {
            cursor.moveToFirst();

            while (!cursor.isAfterLast())
            {
                venues.add(cursor.getItem());
                cursor.moveToNext();
            }
        }
        finally
        {
            cursor.close();
        }

        return venues;
    }

    //Get venue from table
    public Venue getVenue(UUID id)
    {
        DbCursorWrapper cursor = runQuery(
                VenueTable.Cols.UUID + " = ?",
                new String[] { id.toString() }
        );

        try
        {
            if (cursor.getCount() == 0)
            {
                return null;
            }

            cursor.moveToFirst();
            return cursor.getItem();
        }
        finally
        {
            cursor.close();
        }
    }

    //Add venue to table
    public void addVenue(Venue venue)
    {
        ContentValues values = getContentValues(venue);
        mDatabase.insert(VenueTable.NAME, null, values);
    }

    //Update existing venue table entries
    public void updateVenue(Venue venue)
    {
        String uuidString = venue.getId().toString();
        ContentValues values = getContentValues(venue);

        mDatabase.update(VenueTable.NAME, values,
                VenueTable.Cols.UUID + " = ?",
                new String[] { uuidString });
    }

    //Delete existing venue table entry
    public void deleteVenue(UUID uuid)
    {
        mDatabase.delete(VenueTable.NAME, VenueTable.Cols.UUID + " = ?",
                new String[] { uuid.toString() });
    }

    //Search for existing venue table entry
    private DbCursorWrapper runQuery(String whereClause, String[] whereArgs)
    {
        Cursor cursor = mDatabase.query(
                VenueTable.NAME,
                null,           // columns - null selects all columns
                whereClause,
                whereArgs,
                null,           // groupBy
                null,           // having
                null            // orderBy
        );

        return new DbCursorWrapper(cursor);
    }

    //Put venue values in ContentValues
    private static ContentValues getContentValues(Venue venue)
    {
        ContentValues values = new ContentValues();
        values.put(VenueTable.Cols.UUID, venue.getId().toString());
        values.put(VenueTable.Cols.NAME, venue.getName());
        values.put(VenueTable.Cols.ADDRESS, venue.getAddress());
        values.put(VenueTable.Cols.OPENING_TIME, venue.getOpeningTime());
        values.put(VenueTable.Cols.LAT, venue.getLat());
        values.put(VenueTable.Cols.LON, venue.getLon());

        return values;
    }
}


