//Class: VenueDetailsFragment
//Author: Pierce Kinghorn
//LastEdited: 11/4/2020

package com.example.musicpro;

import android.app.AlertDialog;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;

import java.util.UUID;

import static com.example.musicpro.DbProvider.*;

public class VenueDetailsFragment extends Fragment {
    //Initialise layout values
    private Venue mVenue;
    private EditText mName;
    private EditText mAddress;
    private EditText mTime;
    private Button mDoneButton;
    private Button mDeleteButton;

    //Get venue id on create
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UUID venueId = (UUID) getActivity().getIntent().getSerializableExtra("venue_id");
        mVenue = get(getActivity()).getVenue(venueId);
    }

    //Set fields on activity pause
    @Override
    public void onPause() {
        super.onPause();

        mVenue.setName(mName.getText().toString());
        mVenue.setAddress(mAddress.getText().toString());
        mVenue.setOpeningTime(mTime.getText().toString());

        get(getActivity()).updateVenue(mVenue);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_venue_details, container, false);

        //Get layout objects
        mDoneButton = (Button)v.findViewById(R.id.buttondone);
        mDeleteButton = (Button)v.findViewById(R.id.buttondelete);
        mName = (EditText)v.findViewById(R.id.editTextname);
        mName.setText(mVenue.getName());
        mAddress = (EditText)v.findViewById(R.id.editTextaddress);
        mAddress.setText(mVenue.getAddress());
        mTime = (EditText)v.findViewById(R.id.editTexttime);
        mTime.setText(mVenue.getOpeningTime());

        //On done button clicked
        mDoneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Get text from fields
                String name = mName.getText().toString();
                String address = mAddress.getText().toString();

                if (name.equals("") && address.equals(""))
                {
                    //Display Warning
                    AlertDialog builder = new AlertDialog.Builder(getActivity())
                            .setTitle(R.string.warning_title)
                            .setMessage(R.string.are_you_sure)
                            .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //Delete Venue
                                    UUID venueId = (UUID) getActivity().getIntent().getSerializableExtra("venue_id");
                                    DbProvider.get(getActivity()).deleteVenue(venueId);
                                    getActivity().finish();
                                }
                            })
                            .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //Do nothing
                                    dialog.dismiss();
                                }
                            })
                            .show();
                }
                else if (name.equals("") || address.equals("") )
                {
                    //Display Warning
                    AlertDialog builder = new AlertDialog.Builder(getActivity())
                            .setTitle(R.string.warning_title)
                            .setMessage(R.string.warning_message)
                            .show();

                }
                else
                {
                    //Update Venue
                    DbProvider.get(getActivity()).updateVenue(mVenue);
                    getActivity().finish();
                }
            }
        });

        //On delete button clicked
        mDeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Display Warning
                AlertDialog builder = new AlertDialog.Builder(getActivity())
                        .setTitle(R.string.warning_title)
                        .setMessage(R.string.are_you_sure)
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //Delete Venue
                                UUID venueId = (UUID) getActivity().getIntent().getSerializableExtra("venue_id");
                                DbProvider.get(getActivity()).deleteVenue(venueId);
                                getActivity().finish();
                            }
                        })
                        .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //Do nothing
                                dialog.dismiss();
                            }
                        })
                        .show();
            }
        });
        return v;
    }
}
