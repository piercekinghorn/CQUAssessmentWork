//Class: Venue
//Author: Pierce Kinghorn
//LastEdited: 9/4/2020
package com.example.musicpro;

import java.util.UUID;

public class Venue {

    //Initialise venue values
    private UUID mId;
    private String mName;
    private String mAddress;
    private String mTime;
    private double mLat;
    private double mLon;

    //Venue objects
    public Venue(UUID uuid) {
        mId = uuid;
    }

    public Venue() {
        mId = UUID.randomUUID();
    }

    //Get and set methods for venue values.
    public UUID getId(){
        return mId;
    }

    public String getName(){
        return mName;
    }

    public void setName(String name){
        mName = name;
    }

    public String getAddress(){
        return mAddress;
    }

    public void setAddress(String address){
        mAddress = address;
    }

    public String getOpeningTime() {
        return mTime;
    }

    public void setOpeningTime(String time) {
        mTime = time;
    }

    public double getLat() {
        return mLat;
    }

    public void setLat(double lat){
        mLat = lat;
    }

    public double getLon() {
        return mLon;
    }

    public void setLon(double lon){
        mLat = lon;
    }

}
