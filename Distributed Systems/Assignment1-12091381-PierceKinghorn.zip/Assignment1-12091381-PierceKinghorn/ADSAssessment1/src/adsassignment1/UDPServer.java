//Author: Pierce Kinghorn 12091381
//Date: 12/03/2021
//Class: UDP Server
//Purpose: The purpose of this class is to recieve and send data from the
//UPDClient Class while utilizing the WriteToFile Class to write customer
//entries to file.
package adsassignment1;
        
import java.net.*;
import java.io.*;
import java.util.*;

public class UDPServer{
   
    public static void main(String args[]){
                   
        //Initiate Variables
        List<Customer> customerList = new ArrayList<Customer>();

        Customer customer = new Customer();
        String logincheck = "0";
        byte [] signinReply = new byte[1000];
        byte[] buffer = new byte[1000];
        
        //Retrieves Customers on initial startup
        customerList = WriteToFile.retrieve();
        
        //Manages Loop
        int interval = 120000; //Two mintues
        java.util.Timer tm = new java.util.Timer();
        tm.schedule(new WriteToFile(), interval, interval);//Prints customerList to file
        
    	DatagramSocket aSocket = null;              // DatagramSocket declared and initalised.
		try{
	    	aSocket = new DatagramSocket(6789);     //DatagramSocket assigned with port number.
			
			//Infinite loop to listen to clients
			System.out.println("UDP Server running...");
 			while(true){

                            //Retrieves client id from client
                            DatagramPacket signinId = new DatagramPacket(buffer, buffer.length);
                            aSocket.receive(signinId);
                            String customerId = new String(signinId.getData()).trim();
                            
                            //Clears buffer for next request
                            Arrays.fill(buffer, (byte)0);
                            
                            //Retrieves pin number from client
                            DatagramPacket signinPin = new DatagramPacket(buffer, buffer.length);
                            aSocket.receive(signinPin);
                            String customerPin = new String(signinPin.getData()).trim();
                            
                            //Clears buffer for next request
                            Arrays.fill(buffer, (byte)0);
                            
                            //Retieves server action from client
                            DatagramPacket serverAction = new DatagramPacket(buffer, buffer.length);
                            aSocket.receive(serverAction);
                            String action = new String(serverAction.getData()).trim();
                            
                            //Clears buffer for next request
                            Arrays.fill(buffer, (byte)0);
    
                            //Loop to determine login credentials
                            int size = customerList.size();
                            int i = 0;
                            while(i < size){ 
                                
                                //Sets credentials
                                customer = customerList.get(i);
                                String id = customer.getClientId();
                                int pin = customer.getPinNumber();
                                String pins = String.valueOf(pin);
                                
                                //Checks login id
                                if(id.equals(customerId)){         
                                        
                                    //Checks login pin
                                    if(pins.equals(customerPin) ){
                                    
                                        //Determines in or out action
                                        if(action.equals("1"))
                                        {
                                            if(customer.isStatus())
                                            {            
                                                //Already onboard
                                                logincheck = "2";
                                                 
                                            }
                                            else
                                            {
                                                //Sets user status to true
                                                customerList.get(i).setStatus(true);
                                                //Succesfully Login and entry
                                                logincheck = "3";  

                                            }          
                                        }
                                        else if(action.equals("2"))
                                        {
                                            if(customer.isStatus())
                                            {
                                                //Sets user status to false       
                                                customerList.get(i).setStatus(false);
                                                
                                                //Increases number of travels
                                                int num = customerList.get(i).getNumberOfTravels();
                                                num++;
                                                customerList.get(i).setNumberOfTravels(num);
                                                Double cost = customerList.get(i).getTotalCost();
                                                System.out.println(id+"  "+num+"    $"+cost);

                                                //Succesfully logout
                                                logincheck = "5";
                                                                                            
                                            }
                                            else
                                            {
                                                //Not onboard
                                                logincheck = "4";

                                            }       
                                        }                                                                                                                    
                                    }
                                    else
                                    {
                                        //Wrong Password
                                        logincheck = "1";
                                    }
                                    break;
                                }
                                else
                                {
                                    //Wrong username
                                    logincheck = "0";
                                }
                                i++;
                            }
                       
                        //Sends login credentials confirmation
                        signinReply =logincheck.getBytes();
                        DatagramPacket reply = new DatagramPacket(signinReply,signinReply.length ,signinId.getAddress(), signinId.getPort());
    			//send
    			aSocket.send(reply);
    			//clear buffer for next rquest
    			Arrays.fill(buffer, (byte)0);
                            
    		}//end of loop
		}//end of try block
		catch (SocketException e)  //socket exception handling.
		{System.out.println("Socket: " + e.getMessage());
		}
		catch (IOException e)
		{System.out.println("IO: " + e.getMessage());
		}
		finally {if(aSocket != null) aSocket.close();}
    }
}//End Class
