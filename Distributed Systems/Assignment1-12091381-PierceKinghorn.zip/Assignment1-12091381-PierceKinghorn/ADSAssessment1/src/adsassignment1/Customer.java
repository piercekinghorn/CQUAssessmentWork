//Author: Pierce Kinghorn 12091381
//Date: 12/03/2021
//Class: Customer
//Purpose: The purpose of this class to serialize the customer object.
package adsassignment1;

import java.io.Serializable;

public class Customer implements Serializable {
    
    //Customer Values
    private String clientId;
    private int pinNumber;
    private boolean status;
    private int numberOfTravels = 0;
    
    private double totalCost;
    
    public Customer(){
        
    }
    
    public Customer(String clientId, int pinNumber, boolean status, int numberOfTravels)
    {
        this.clientId = clientId;
        this.pinNumber = pinNumber;
        this.status = status;
        this.numberOfTravels = numberOfTravels;     
    }

    //Customer Get Methods
    public String getClientId() {
        return clientId;
    }

    public int getPinNumber() {
        return pinNumber;
    }

    public boolean isStatus() {
        return status;
    }

    public int getNumberOfTravels() {
        return numberOfTravels;
    }

    //Customer Set Methods
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public void setPinNumber(int pinNumber) {
        this.pinNumber = pinNumber;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public void setNumberOfTravels(int numberOfTravels) {
        this.numberOfTravels = numberOfTravels;
    }
    
    //Cost Calculations
    public double getTotalCost() {
        calculateTotalCost();
        return totalCost;
    }    

    public void calculateTotalCost(){
        
        if(numberOfTravels > 5)
        {
            int excessTravel;
            excessTravel = numberOfTravels - 5;
            this.totalCost = excessTravel * 3;           
        }
        else
        {
            this.totalCost = 0.0;
        }
    }
    
    //To String method
    @Override
    public String toString(){
        
        return "Customer{" +
               "clientid='" + clientId + '\'' + 
               "clientid='" + pinNumber + '\'' + 
                '}';
               
    }
    
    

    
}
