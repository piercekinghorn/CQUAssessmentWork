//Author: Pierce Kinghorn 12091381
//Date: 12/03/2021
//Class: UDP Client
//Purpose: The purpose of this class is to recieve and send data from the
//UPDServer Class depending on user inputs.
package adsassignment1;

import java.net.*;
import java.io.*;
import java.util.*;

public class UDPClient {
    
    public static void main(String args[])
    {
        // DatagramSocket declared and initalised.
        DatagramSocket aSocket = null;          
		try {
                        //DatagramSocket assigned.
			aSocket = new DatagramSocket();
                        //Scanner instance assigned.
			Scanner sa=new Scanner(System.in);  
			//Host address designated to localhost
			InetAddress aHost = InetAddress.getByName("localhost");
			//Byte array used to send and receive a maximum of 1000 characters.
                        byte [] m = new byte[1000];
			byte [] id = new byte[1000];
                        byte [] pin = new byte[1000];
                        byte [] svac = new byte[1000];
                        byte[] buffer = new byte[1000];
                        
			//Port number for the process to listen at.
			int serverPort = 6789;
                        //String Variables
			String input="";
                        String selection=""; 
                        String clientId="";
                        String clientPin="";
                        String loginConfirmation="";
                        String logoutConfirmation="";
                        //action: 1 = login, 2 = logout
                        String action = "0";
                        
			//Loops until user selects exit
			while(! selection.equalsIgnoreCase("3"))
			{
			System.out.println("*********Travel Kiosk*********");
                        System.out.println("           1:IN               ");
                        System.out.println("           2:OUT              ");
                        System.out.println("           3:EXIT             ");
                        
                        //Scans next input
                        selection=sa.nextLine();
                        
                        //In/Login Selection
                        if("1".equals(selection)){
                            
                            System.out.println("Enter: 1");
                            
                            //Converts Action
                            action = "1";
                            svac=action.getBytes();
                            
                            //Converts Id
                            System.out.println("Enter client id:");
                            clientId=sa.nextLine();
                            id=clientId.getBytes();
                            
                            //Converts Pin
                            System.out.println("Enter client pin");
                            clientPin=sa.nextLine();
                            pin=clientPin.getBytes();
                            
                            //Send login id
                            DatagramPacket signinId =new DatagramPacket(id,id.length, aHost, serverPort);
                            aSocket.send(signinId);
                            
                            //Send login pin
                            DatagramPacket signinPin =new DatagramPacket(pin,pin.length, aHost, serverPort);
                            aSocket.send(signinPin);
                            
                            //Send action request
                            DatagramPacket serverAction =new DatagramPacket(svac,svac.length, aHost, serverPort);
                            aSocket.send(serverAction);
                            
                            //Recieve Login Confirmation
                            DatagramPacket reply  = new DatagramPacket(buffer, buffer.length);
                            aSocket.receive(reply);
                            loginConfirmation = new String(reply.getData()).trim();
                            
                            //Clear Buffer
                            Arrays.fill(buffer, (byte)0);
                            
                            //Wrong id
                            if(loginConfirmation.equals("0")){
                                System.out.println("Invalid Customer");
                            }
                            //Wrong pin
                            else if(loginConfirmation.equals("1")){
                                System.out.println("Error-Invalid Pin Number");
                            }
                            //Already onboard
                            else if(loginConfirmation.equals("2")){
                                System.out.println("Error-Already signed-in");
                            }
                            //Successfull login
                            else if(loginConfirmation.equals("3")){
                                System.out.println("Success - Welcome!");
                            }
                               
                        //End Login if
                        }
                        //Out/logout selection
                        if("2".equals(selection)){
                            
                            //Converts Action
                            action = "2";
                            svac=action.getBytes();
                            
                            //Converts Id
                            System.out.println("Enter: 2");
                            System.out.println("Enter client id:");
                            clientId=sa.nextLine();
                            id=clientId.getBytes();
                            
                            //Converts Pin
                            System.out.println("Enter client pin");
                            clientPin=sa.nextLine();
                            pin=clientPin.getBytes();
                            
                            //Send login id
                            DatagramPacket signinId =new DatagramPacket(id,id.length, aHost, serverPort);
                            aSocket.send(signinId);
                            
                            //Send login pin
                            DatagramPacket signinPin =new DatagramPacket(pin,pin.length, aHost, serverPort);
                            aSocket.send(signinPin);
                            
                            //Send action request
                            DatagramPacket serverAction =new DatagramPacket(svac,svac.length, aHost, serverPort);
                            aSocket.send(serverAction);
                            
                            //Recieve Logout Confirmation
                            DatagramPacket reply  = new DatagramPacket(buffer, buffer.length);
                            aSocket.receive(reply);
                            logoutConfirmation = new String(reply.getData()).trim();
                            
                            //Clear Buffer
                            Arrays.fill(buffer, (byte)0);
                            
                            //Wrong id
                            if(logoutConfirmation.equals("0")){
                                System.out.println("Invalid Customer");
                            }
                            //Wrong pin
                            else if(logoutConfirmation.equals("1")){
                                System.out.println("Error-Invalid Pin Number");
                            }
                            //Not on-board
                            else if(logoutConfirmation.equals("4")){
                                System.out.println("Error-Already signed-out");
                            }
                            //Successfull logout
                            else if(logoutConfirmation.equals("5")){
                                System.out.println("Success - GoodBye!");
                            }         
                        //End logout if
                        }
                           
		    }//End while
		}//End try
		catch (SocketException e)
		{
		System.out.println("Socket: " + e.getMessage());
		}
		catch (IOException e)
		{System.out.println("IO: " + e.getMessage());
		}
		finally
		{if(aSocket != null) aSocket.close();
		}
    }   
}