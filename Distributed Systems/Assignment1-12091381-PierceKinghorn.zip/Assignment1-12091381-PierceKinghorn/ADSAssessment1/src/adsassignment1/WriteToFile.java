//Author: Pierce Kinghorn 12091381
//Date: 12/03/2021
//Class: WriteToFile
//Purpose: The purpose of this class is to manage both the
//writing and retieval of information from the members.dat file.
//This class also extends TimerTask which will write the Customer ArrayList to
//File every 2 minutes.
package adsassignment1;

import java.io.*;
import java.util.*;
public class WriteToFile extends TimerTask {
    
    
    static List<Customer> customerList = new ArrayList<Customer>();
    static String RetFile = "member.txt";
    static String WriteFile = "member.dat";
    
    //Writes CustomerArrayList to file
    public static void write(List<Customer> customerList){
             
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
        
        try
        {
            fos = new FileOutputStream(WriteFile);
            out = new ObjectOutputStream(fos);
            out.writeObject(customerList);
            out.close();
            System.out.println("Writing Complete");
        }
        catch(IOException ex)
        {
            ex.printStackTrace();
        }        
    }    
    //Retrieves CustomerArrayList from file
    public static List<Customer> retrieve(){
        
        try
        {  
            BufferedReader inFile = new BufferedReader(new FileReader(RetFile));
            
            String inputLine;
            while ( (inputLine = inFile.readLine()) !=null){
                Customer customer = new Customer();
                String[] line = inputLine.split(" ");

                customer.setClientId(line[0]);    
                int pin = Integer.parseInt(line[1].trim());   
                customer.setPinNumber(pin);
                customerList.add(customer);                                       
            }     

        inFile.close();
        }
	   
	catch(IOException ex) {
	    ex.printStackTrace();
	}
        return customerList;    
    }     
    
    //Resets the number of travels
    public void run(){
        write(customerList);
    }

}
 
