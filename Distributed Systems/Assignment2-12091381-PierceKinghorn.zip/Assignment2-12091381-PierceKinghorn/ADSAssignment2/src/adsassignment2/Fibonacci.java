/*
Author: Pierce Kinghorn
File Name: Fibonacci
Date: 04/05/2021
Purpose: Is sent between TCPClient and TCPServer and performs
fibonacci calculations
 */
package adsassignment2;

import java.io.*;

public class Fibonacci implements Serializable, Task {

    //Creates variables
    //holds recieved int
    int num;
    //holds calculated answer
    int answer;
    //holds returning string
    String result;

    public Fibonacci() {
    }

    public Fibonacci(int number) {
        this.num = number;
    }

    @Override
    public void executeTask() {

        if (num == 1 || num == 2) {
            answer = 1;
            return;
        }
        int fibo1 = 1, fibo2 = 1, fibonacci = 1;
        for (int i = 3; i <= num; i++) {

            fibonacci = fibo1 + fibo2;
            fibo1 = fibo2;
            fibo2 = fibonacci;

        }
        answer = fibonacci;
    }

    @Override
    public String getResults() {
        result = String.valueOf(answer);
        return result;
    }
}//End class
