/*
Author: Pierce Kinghorn
Class: TCPServer
Date: 04/05/2021
Purpose: Allows connections from multiple TCPClient instances and performs
the calculation methods stored within the Factorial, Fibonacci, and Gcd Classes.
constructs the Cryptography class to recieve a keypair for login encryption,
and constructs the DatabaseConnection class for login credential verification.
 */
package adsassignment2;

import java.net.*;
import java.io.*;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TCPServer {

    public static void main(String args[]) throws Exception {

        try {
            // the port number the process listens at.
            int serverPort = 8888;
            // TCP server socket assigned to the port number
            ServerSocket listenSocket = new ServerSocket(serverPort);
            System.out.println("TCP Server running...");
            //Server sitting in an infinite loop waiting for clients to connect.
            while (true) {
                //connecting with the client established
                Socket clientSocket = listenSocket.accept();
                // assign a new thead to deal with the client and contine to accept more clients
                Connection c = new Connection(clientSocket);
            }

        }//end of try
        catch (IOException e) //excpetion handling
        {
            System.out.println("Listen socket:" + e.getMessage());
        }
    }//emd of main
} //end of TCPServer

class Connection extends Thread {

    ObjectInputStream in;
    ObjectOutputStream out;
    Socket clientSocket;
    String username = "name";
    String password = "password";

    public Connection(Socket aClientSocket) {

        try {
            clientSocket = aClientSocket;
            in = new ObjectInputStream(clientSocket.getInputStream());
            out = new ObjectOutputStream(clientSocket.getOutputStream());
            this.start();
        } catch (IOException e) {
            System.out.println("Connection:" + e.getMessage());
        }
    }

    public void run() {

        try {
            //Creating variables
            //Holds recieved name
            String name = "";
            //Holds recieved pass
            String pass = "";

            //Generates Keys
            KeyPair keyPair = Cryptography.GenerateKeys();
            PublicKey pubKey = keyPair.getPublic();
            PrivateKey privateKey = keyPair.getPrivate();

            //Reciveing, executing, and replying/
            while (true) {
                //Recieves object
                Object obj = in.readObject();
                //Checks if first time connection
                if (obj instanceof String) {
                    //Sends public key
                    out.writeObject(pubKey);
                }
                //Login object
                if (obj instanceof byte[]) {

                    //Sets variable
                    byte[] recieved = null;
                    //Assigns variable
                    recieved = ((byte[]) obj);
                    byte[] verified = Cryptography.decrypt(privateKey, recieved);

                    //Splits variable to name and pass
                    String[] logindetails = new String(verified).split(":", 2);
                    name = logindetails[0];
                    pass = logindetails[1];

                    //Compares name and password in database
                    String verification = DatabaseConnection.connection(name, pass);

                    //Sends back verification
                    if (verification.equals("0")) {
                        //Incorrect Password
                        out.writeObject("0");
                    } 
                    if (verification.equals("1")) {
                        //Incorrect Password
                        out.writeObject("1");
                    } 
                    if (verification.equals("2")) {
                        //Success
                        System.out.println("User verified");
                        out.writeObject("2");                       
                    }
                }
                //Factorial Object
                if (obj instanceof Factorial) {
                    ((Factorial) obj).executeTask();
                    System.out.println(name + " performed factorial calculation");
                    out.writeObject(obj);
                }
                //Fibonacci Object
                if (obj instanceof Fibonacci) {
                    ((Fibonacci) obj).executeTask();
                    System.out.println(name + " performed fibonacci calculation");
                    out.writeObject(obj);
                }
                //Gcd Object
                if (obj instanceof Gcd) {
                    ((Gcd) obj).executeTask();
                    System.out.println(name + " performed gcd calculation");
                    out.writeObject(obj);
                }
            }//end of while
        }// end of try
        catch (EOFException e) {
            System.out.println("EOF:" + e.getMessage());
        } catch (IOException e) {
            System.out.println("readline:" + e.getMessage());
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (Exception ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {/*close failed*/
            }
        }
    }
}//End Class
