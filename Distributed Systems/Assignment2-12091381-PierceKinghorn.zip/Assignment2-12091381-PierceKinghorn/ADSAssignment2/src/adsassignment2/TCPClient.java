/*
Author: Pierce Kinghorn
File Name: TCPClient
Date: 04/05/2021
Purpose: Connects to the TCPServer class and is the tool in which users
interact with in order to perform program functions. Constructs the Factorial,
Fibonacci, and Gcd Classes to store variables to be sent to the TCPServer.
 */
package adsassignment2;

import java.net.*;
import java.io.*;
import java.security.PublicKey;
import java.util.*;

public class TCPClient {

    public static void main(String args[]) throws Exception {

        //socket initialised to null.
        Socket s = null;
        //Scanner instanse to recive input from the user.
        Scanner sa = new Scanner(System.in);
        try {
            //port number the process listens at.
            int serverPort = 8888;
            // tcp clinet socket assigned.
            s = new Socket("localhost", serverPort);

            //strings to hold user input.
            String input = "";
            String username = "";
            String gcd2 = "";
            String selection = "";
            PublicKey pubKey = null;
            // input and output streams initalised to null.
            ObjectInputStream in = null;
            ObjectOutputStream out = null;

            // input and output streams assigned and linked to the socket
            out = new ObjectOutputStream(s.getOutputStream());
            in = new ObjectInputStream(s.getInputStream());

            //recieving public key for encryption
            out.writeObject("Request");
            Object obj = in.readObject();
            if (obj instanceof PublicKey) {
                pubKey = ((PublicKey) obj);
            }

            //keep chatting until user terminates with exit
            while (!input.equalsIgnoreCase("exit")) {
                //Login
                String confirmation;

                //Scan username
                System.out.println("Enter Username");
                username = sa.nextLine();
                //Scan password
                System.out.println("Enter Password");
                input = sa.nextLine();
                //Combine Strings
                input = String.join(":", username, input);
                //Create and set datavariable
                byte[] data;
                data = Cryptography.encrypt(pubKey, input);
                //send data to server
                out.writeObject(data);
                //recieve password confirmation
                confirmation = (String) in.readObject();

                //print login confirmation messages
                if (confirmation.equals("0")) {
                    System.out.println("*******Invalid User*******");
                }
                
                if (confirmation.equals("1")) {
                    System.out.println("*****Invalid Password*****");
                }
                
                if (confirmation.equals("2")) {
                    System.out.println("*********Success**********");
                    System.out.println("Welcome " + username + " please make a selection");
                }

                //While logged in
                while (confirmation.equals("2")) {

                    System.out.println("======================");
                    System.out.println("        SELECT        ");
                    System.out.println("1.     Factorial      ");
                    System.out.println("2.     Fibonacci      ");
                    System.out.println("3.        GCD         ");
                    System.out.println("4.      LogOut        ");
                    System.out.println("======================");

                    selection = sa.nextLine().trim();

                    //Factorial
                    if ("1".equals(selection)) {
                        System.out.println("You have selected: Factorial");
                        System.out.println("Enter Number");
                        input = sa.nextLine();

                        if (input.equals("")) {

                           System.out.println("Missing Paramters");
                        } else {
                            Factorial f = new Factorial(Integer.parseInt(input));
                            out.writeObject(f);
                            System.out.println("The Factorial of " + input + " is: " + ((Factorial) in.readObject()).getResults());
                        }
                    }

                    //Fibonacci
                    if ("2".equals(selection)) {
                        System.out.println("You have selected: Fibonacci");
                        System.out.println("Enter Number");
                        input = sa.nextLine();

                        if (input.equals("")) {
                            System.out.println("Missing Paramters");
                        } else {
                            Fibonacci f = new Fibonacci(Integer.parseInt(input));
                            out.writeObject(f);
                            System.out.println("The Fibonacci of " + input + " is: " + ((Fibonacci) in.readObject()).getResults());
                        }
                    }

                    //Greatest common denominator
                    if ("3".equals(selection)) {
                        System.out.println("You have selected: Gcd");
                        System.out.println("Enter Your First Number");
                        input = sa.nextLine();
                        System.out.println("Enter Your Second Number");
                        gcd2 = sa.nextLine();

                        if (input.equals("") || gcd2.equals("")) {

                            System.out.println("Missing Paramters");
                        } else {
                            Gcd f = new Gcd(Integer.parseInt(input), Integer.parseInt(gcd2));
                            out.writeObject(f);
                            System.out.println("The Gcd of " + input + " and " + gcd2 + " is: " + ((Gcd) in.readObject()).getResults());
                        }
                    }
                    if ("4".equals(selection)) {
                        System.out.println("GoodBye!");
                        confirmation = "0";
                    }
                }
            } //end of while

        } //end of try block
        catch (UnknownHostException e) //socket exception handling.
        {
            System.out.println("Socket:" + e.getMessage());
        } catch (EOFException e) {
            System.out.println("EOF:" + e.getMessage());
        } catch (IOException e) {
            System.out.println("readline:" + e.getMessage());
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } finally {
            if (s != null) {
                try {
                    s.close();
                } catch (IOException e) {
                    System.out.println("close:" + e.getMessage());
                }
            }
        }
    }
}//End class
