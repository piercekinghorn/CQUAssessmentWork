/*
Author: Pierce Kinghorn
File Name: Gcd
Date: 04/05/2021
Purpose: Is sent between TCPClient and TCPServer and performs
Gcd calculations 
 */
package adsassignment2;

import java.io.*;

public class Gcd implements Serializable, Task {

    //Creates variables
    //holds first recieved int
    int num1;
    //holds second recieved int
    int num2;
    //holds calculated answer
    int answer;
    //holds returning result
    String result;

    public Gcd() {

    }

    public Gcd(int number1, int number2) {

        this.num1 = number1;
        this.num2 = number2;
    }

    @Override
    public void executeTask() {

        //performs calculation
        for (int i = 1; i <= num1 && i <= num2; i++) {
            if (num1 % i == 0 && num2 % i == 0) {
                answer = i;
            }
        }
    }

    @Override
    public String getResults() {

        //returns result
        result = String.valueOf(answer);
        return result;
    }
}//End class
