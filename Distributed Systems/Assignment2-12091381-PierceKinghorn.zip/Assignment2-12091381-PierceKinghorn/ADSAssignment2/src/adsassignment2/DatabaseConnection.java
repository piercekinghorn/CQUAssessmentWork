/*
Author: Pierce Kinghorn
File Name: DatabaseConnection
Date: 04/05/2021
Purpose: Retrieves client login details from Clients Database for
login verification
 */
package adsassignment2;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {

    public static String connection(String username, String password) throws SQLException {

        //Create database connection
        Connection dbConnection = null;
        //Initialiser
        String result = "0";

        //Check for driver
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (Exception e) {
            System.out.println(e.toString());
        }

        //Starts dbconnection
        try {
            //Database url
            String url = "jdbc:derby://localhost:1527/Clients";

            dbConnection = DriverManager.getConnection(url);

            //Creating and executing statements
            Statement stmt;
            stmt = dbConnection.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Users ");

            //Comparing username
            while (rs.next()) {
                String name = rs.getString("USERID");
                if (name.equals(username)) {
                    //Comparing password
                    String pass = rs.getString("USERPASSWORD");
                    if (pass.equals(password)) {
                        //Returns verification
                        result = "2";
                    }
                    else
                    {
                        result = "1";
                    }
                    //End while early
                    break;
                }
            }//End while
        //Error
        } catch (SQLException ex) {
            System.out.println("An error occurred while connecting to databse");
            ex.printStackTrace();
        }

        //Returned verification 0=incorrect user, 1=incorrect password,
        //2= valid login. 0 by default
        return result;
    }
}
