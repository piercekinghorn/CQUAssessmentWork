/*
Author: Pierce Kinghorn
File Name: Factorial
Date: 04/05/2021
Purpose: Is sent between TCPClient and TCPServer and performs
factorial calculations
 */
package adsassignment2;

import java.io.*;

public class Factorial implements Serializable, Task {

    //Create variables
    //holds recieved number
    int num;
    //holds answer
    int answer;
    //holds returning result
    String result;

    public Factorial() {

    }

    public Factorial(int number) {
        //Variables are set from here
        this.num = number;
    }

    @Override
    public void executeTask() {

        //Calculations performed here
        int i;
        int fact = 1;

        for (i = 1; i <= num; i++) {
            fact = fact * i;
        }
        answer = fact;
    }

    @Override
    public String getResults() {

        //Result returned here
        result = String.valueOf(answer);
        return result;
    }

}//End class
