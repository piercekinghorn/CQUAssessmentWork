/*
Author: Pierce Kinghorn
File Name: Task
Date: 04/05/2021
Purpose: 
 */
package adsassignment2;

//Factorial, Fibonacci, and Gcd Implement this interface.
public interface Task {    
    public void executeTask();
    public String getResults(); 
}//End Interface
