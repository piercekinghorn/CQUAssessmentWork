<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

class EquipmentItem extends Entity
{
    protected $_accessible = [
        'equipment_name' => true,
        'equipment_campus' => true,
        'equipment_lab' => true,
        'equipment_discipline' => true,
        'equipment_location' => true,
        'equipment_details' => true,
        'equipment_media' => true,
        'equipment_whs' => true,
        'equipment_status' => true,
        'equipment_needinduction' => true,
    ];

    public function getName()
    {
        return $this->equipment_name;
    }
}
