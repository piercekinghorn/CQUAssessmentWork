//Author; Pierce Kinghorn
//Date: 23/05/2020
package trafficproject;

import trafficproject.Model.TrafficModel;
import trafficproject.Presenter.TrafficPresenter;
import trafficproject.View.ITrafficView;
import trafficproject.View.TrafficView;
import trafficproject.Model.ITrafficModel;

public class TrafficProject {

    public static void main(String[] args) {
        
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");    
        } catch (Exception e) {
            System.out.println(e.toString());
        }  
        
        //Create an instance of TrafficModel instance
        ITrafficModel tm=new TrafficModel();
        //Create an instance of TrafficView instance
        ITrafficView  itv=new TrafficView();
        //Create an instance of TrafficPresenter with access to model and view
        TrafficPresenter tp=new TrafficPresenter(itv,tm);
        //Assign view access to TrafficPresenter
        itv.bind(tp);   
    }
    
}//End Class
