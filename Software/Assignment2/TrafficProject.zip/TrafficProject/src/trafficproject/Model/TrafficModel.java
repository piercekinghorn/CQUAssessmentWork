//Author; Pierce Kinghorn
//Date: 23/05/2020
package trafficproject.Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

public class TrafficModel implements ITrafficModel{
    
    private static final String URL = "jdbc:derby://localhost:1527/accidentdatabase_2";
    private static final String USERNAME = "Username";
    private static final String PASSWORD = "Password";

    private Connection connection = null; // manages connection
    private PreparedStatement selectAllVehicles = null; 
    private PreparedStatement selectAllAccidents = null; 
    private PreparedStatement selectAllVehicleAccidents = null; 
    private PreparedStatement insertNewVehicle = null; 
    private PreparedStatement insertNewAccident = null; 
    private PreparedStatement insertNewVehicleAccident = null; 
    private PreparedStatement searchByVehicleId = null; 
    private PreparedStatement searchByOwnerName = null;
    private PreparedStatement searchByAccidentID = null; 
    private PreparedStatement updateAccident = null;
    private PreparedStatement updateVehicle = null;
    private PreparedStatement searchByVID = null;
    
       // constructor
    public TrafficModel()
    {
        try {
            
            connection = DriverManager.getConnection( URL,USERNAME,PASSWORD );
            
            //Database tables ACCIDENT, VEHICLE, ACCIDENT_VEHICLE
            
            //Creating all use queries
            //Accident Queries
            selectAllAccidents = connection.prepareStatement("SELECT * FROM ACCIDENT");
            insertNewAccident = connection.prepareStatement("INSERT INTO ACCIDENT " + "( Location, Comments ) " + "VALUES ( ?, ?)" );
            updateAccident = connection.prepareStatement("UPDATE ACCIDENT SET LOCATION = ? , COMMENTS = ? WHERE ACCIDENTID = ?");
            searchByAccidentID = connection.prepareStatement("SELECT * FROM ACCIDENT WHERE ACCIDENTID = ?");
            //Vehicle Queries
            selectAllVehicles = connection.prepareStatement(" SELECT * FROM VEHICLE");
            insertNewVehicle = connection.prepareStatement("INSERT INTO VEHICLE " + "(vehicle_id, model, make_year, owner_name, address, phone)" + "VALUES (?,?,?,?,?,?)");
            updateVehicle = connection.prepareStatement("UPDATE VEHICLE SET MODEL = ? , MAKE_YEAR = ?, OWNER_NAME = ?, ADDRESS = ?, PHONE = ? WHERE VEHICLE_ID = ?");
            searchByVehicleId = connection.prepareStatement("SELECT * FROM VEHICLE WHERE VEHICLE_ID = ?");
            searchByOwnerName = connection.prepareStatement("SELECT * FROM VEHICLE WHERE OWNER_NAME= ?");
            //Vehicle Accident Queries
            selectAllVehicleAccidents = connection.prepareStatement("SELECT * FROM ACCIDENT_VEHICLE");
            searchByVID = connection.prepareStatement("SELECT * FROM ACCIDENT_VEHICLE WHERE VEHICLE_ID = ?");
            insertNewVehicleAccident = connection.prepareStatement("INSERT INTO ACCIDENT_VEHICLE" + "(vehicle_id, accident_id)" + "VALUES (?,?)");
            
        } catch (Exception e) {
            e.printStackTrace();
            System.exit( 1 );
        }
    }
    
    //Accident Methods
    @Override
    public int addAccident(String location, String comments )
    {  
        int result = 0;
      
        try 
        {
            insertNewAccident.setString( 1, location );
            insertNewAccident.setString( 2, comments );

            // insert the new entry; returns # of rows updated
            result = insertNewAccident.executeUpdate(); 
        } // end try
        catch ( SQLException sqlException )
        {
            sqlException.printStackTrace();
            close();
        } // end catch
      
        return result;
    } // end method addAccident
    
    public int updateAccident(String location, String comments, String accidentId )
    {
        
        int result = 0;
      
        try 
        {
            updateAccident.setString( 1, location );
            updateAccident.setString( 2, comments );
            updateAccident.setString( 3, accidentId);

            // insert the new entry; returns # of rows updated
            result = updateAccident.executeUpdate(); 
        } // end try
        catch ( SQLException sqlException )
        {
            sqlException.printStackTrace();
            close();
        } // end catch
      
        return result;
    } // end method updateAccident
       
    @Override
    public List< Accident > getAllAccidents()
    {
        List< Accident> accidentResults = null;
        ResultSet accidentResultSet = null;

        //Creates an Accident List Containing All Acident Objects from database
        try {
                accidentResultSet = selectAllAccidents.executeQuery(); 
                accidentResults = new ArrayList<Accident>();
                
                while ( accidentResultSet.next() )
                {
                    accidentResults.add(new Accident(
                    accidentResultSet.getString( "ACCIDENTID" ),
                    accidentResultSet.getString( "LOCATION" ),
                    accidentResultSet.getString( "COMMENTS" ),
                    accidentResultSet.getDate( "ACCIDENT_DATE" )
                    ));
                } // end while
            
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();  
        }
        finally
        {
            try 
            {  
                accidentResultSet.close();
            } // end try 
            catch ( SQLException sqlException )
            {
                sqlException.printStackTrace();         
                close();
            } // end catch
        } // end finally

        //accidentResult is a List
        return accidentResults;
    } // end method getAllAccidents
    
    @Override
    public List< Accident > searchAccidentById(int accidentId)
    {
        List< Accident> accidentResults = null;
        ResultSet accidentResultSet = null;
        
        try {
                searchByAccidentID.setInt( 1, accidentId );
                accidentResultSet = searchByAccidentID.executeQuery(); 
                accidentResults = new ArrayList<Accident>();
                
                while ( accidentResultSet.next() )
                {
                    accidentResults.add(new Accident(
                    accidentResultSet.getString( "ACCIDENTID" ),
                    accidentResultSet.getString( "LOCATION" ),
                    accidentResultSet.getString( "COMMENTS" ),
                    accidentResultSet.getDate( "ACCIDENT_DATE" )
                    ));
                } // end while
            
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();  
        }
        finally
        {
            try 
            {
                accidentResultSet.close();
            } // end try // end try
            catch ( SQLException sqlException )
            {
                sqlException.printStackTrace();         
                close();
            } // end catch
        } // end finally

        //accidentResult is a List
        return accidentResults;
    } // end method searchByAccidentId
    
    //Vehicle Methods
    @Override
    public int addVehicle(String vehicle_id, String model, String make_year, String owner_name, String address, String phone)
    {
        int result = 0;

        try 
        {
            insertNewVehicle.setString( 1, vehicle_id );
            insertNewVehicle.setString( 2, model );
            insertNewVehicle.setString( 3, make_year);
            insertNewVehicle.setString( 4, owner_name);
            insertNewVehicle.setString( 5, address);
            insertNewVehicle.setString( 6, phone);

            result = insertNewVehicle.executeUpdate(); 
        } // end try
        catch ( SQLException sqlException )
        {
            sqlException.printStackTrace();
            close();
        } // end catch
      
        return result;
    } // end method addVehicle
    
    @Override
    public int updateVehicle(String vehicle_id, String model, String make_year, String owner_name, String address, String phone)
    {
        int result = 0;
        
        try 
        {
            updateVehicle.setString( 1, model );
            updateVehicle.setString( 2, make_year);
            updateVehicle.setString( 3, owner_name);
            updateVehicle.setString( 4, address);
            updateVehicle.setString( 5, phone);
            updateVehicle.setString( 6, vehicle_id );

            result = updateVehicle.executeUpdate(); 
        } // end try
        catch ( SQLException sqlException )
        {
            sqlException.printStackTrace();
            close();
        } // end catch
      
        return result;
    } // end method updateVehicle
    
    @Override
    public List< Vehicle > getAllVehicles()
    {
        List<Vehicle> vehicleResults = null;
        ResultSet vehicleResultSet = null;

        try {
                vehicleResultSet = selectAllVehicles.executeQuery(); 
                vehicleResults = new ArrayList<Vehicle>();
                
                while ( vehicleResultSet.next() )
                {
                    vehicleResults.add(new Vehicle(
                    vehicleResultSet.getString( "VEHICLE_ID" ),
                    vehicleResultSet.getString( "MODEL" ),
                    vehicleResultSet.getInt( "MAKE_YEAR" ),
                    vehicleResultSet.getString( "OWNER_NAME" ),
                    vehicleResultSet.getString( "ADDRESS" ),
                    vehicleResultSet.getInt( "PHONE" )
                    ));
                } // end while
            
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();  
        }
        finally
        {
            try 
            {
                vehicleResultSet.close();
            } // end try
            catch ( SQLException sqlException )
            {
                sqlException.printStackTrace();         
                close();
            } // end catch
        } // end finally
        return vehicleResults;
    } // end method getAllVehicles
    
    @Override
    public List< Vehicle > searchByVehicleId(String vehicle_id)
    {
        List<Vehicle> vehicleResults = null;
        ResultSet vehicleResultSet = null;

        try {
                searchByVehicleId.setString( 1, vehicle_id );
                vehicleResultSet = searchByVehicleId.executeQuery(); 
                vehicleResults = new ArrayList<Vehicle>();
                
                while ( vehicleResultSet.next() )
                {
                    vehicleResults.add(new Vehicle(
                    vehicleResultSet.getString( "VEHICLE_ID" ),
                    vehicleResultSet.getString( "MODEL" ),
                    vehicleResultSet.getInt( "MAKE_YEAR" ),
                    vehicleResultSet.getString( "OWNER_NAME" ),
                    vehicleResultSet.getString( "ADDRESS" ),
                    vehicleResultSet.getInt( "PHONE" )
                    ));
                } // end while
            
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();  
        }
        finally
        {
            try 
            {
                vehicleResultSet.close();
            } // end try // end try
            catch ( SQLException sqlException )
            {
                sqlException.printStackTrace();         
                close();
            } // end catch
        } // end finally

        //accidentResult is a List
        return vehicleResults;
    } // end method searchByVehicleId
        
    @Override
    public List< Vehicle > searchByOwnerName(String owner_name)
    {
        List<Vehicle> vehicleResults = null;
        ResultSet vehicleResultSet = null;

        try {
                searchByOwnerName.setString( 1, owner_name );
                vehicleResultSet = searchByOwnerName.executeQuery(); 
                vehicleResults = new ArrayList<Vehicle>();
                
                while ( vehicleResultSet.next() )
                {
                    vehicleResults.add(new Vehicle(
                    vehicleResultSet.getString( "VEHICLE_ID" ),
                    vehicleResultSet.getString( "MODEL" ),
                    vehicleResultSet.getInt( "MAKE_YEAR" ),
                    vehicleResultSet.getString( "OWNER_NAME" ),
                    vehicleResultSet.getString( "ADDRESS" ),
                    vehicleResultSet.getInt( "PHONE" )
                    ));
                } // end while
            
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();  
        }
        finally
        {
            try 
            {
                vehicleResultSet.close();
            } // end try
            catch ( SQLException sqlException )
            {
                sqlException.printStackTrace();         
                close();
            } // end catch
        } // end finally
        return vehicleResults;
    } // end method searchByOwnerName
    
    //Vehicle Accident Methods
    @Override
    public int addVehicleAccident(String vehicle_id, String accident_id )
    {
        int result = 0;
        
        try 
        {
            insertNewVehicleAccident.setString( 1, vehicle_id );
            insertNewVehicleAccident.setString( 2, accident_id );

            result = insertNewVehicleAccident.executeUpdate(); 
        } // end try
        catch ( SQLException sqlException )
        {
            sqlException.printStackTrace();
            close();
        } // end catch
      
        return result;
    } // end method addVehicleAccident
    
    @Override
    public List< VehicleAccident > getAllVehicleAccidents()
    {
        List<VehicleAccident> vehicleAccidentResults = null;
        ResultSet vehicleAccidentResultSet = null;

        try {
                vehicleAccidentResultSet = selectAllVehicleAccidents.executeQuery(); 
                vehicleAccidentResults = new ArrayList<VehicleAccident>();
                
                while ( vehicleAccidentResultSet.next() )
                {
                    vehicleAccidentResults.add(new VehicleAccident(
                    vehicleAccidentResultSet.getInt( "ACCIDENT_ID" ),
                    vehicleAccidentResultSet.getString( "VEHICLE_ID" )
                    ));
                } // end while
            
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();  
        }
        finally
        {
            try 
            {
                vehicleAccidentResultSet.close();
            } // end try
            catch ( SQLException sqlException )
            {
                sqlException.printStackTrace();         
                close();
            } // end catch
        } // end finally

        //accidentResult is a List
        return vehicleAccidentResults;
    } // end method getAllVehicleAccidents
    
    public List< VehicleAccident > getAllVehicleAccidentsByVID(String vehicle_id)
    {
        List<VehicleAccident> vehicleAccidentResults = null;
        ResultSet vehicleAccidentResultSet = null;

        try {
                searchByVID.setString( 1, vehicle_id );
                vehicleAccidentResultSet = searchByVID.executeQuery(); 
                vehicleAccidentResults = new ArrayList<VehicleAccident>();
                
                while ( vehicleAccidentResultSet.next() )
                {
                    vehicleAccidentResults.add(new VehicleAccident(
                    vehicleAccidentResultSet.getInt( "ACCIDENT_ID" ),
                    vehicleAccidentResultSet.getString( "VEHICLE_ID" )

                    ));
                } // end while
            
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();  
        }
        finally
        {
            try 
            {
                vehicleAccidentResultSet.close();
            } // end try
            catch ( SQLException sqlException )
            {
                sqlException.printStackTrace();         
                close();
            } // end catch
        } // end finally
        return vehicleAccidentResults;
    } // end method getAllVehicleAccidentsByVID
    
    //General Methods
    public void close()
    {
      try 
      {
         connection.close();
      } // end try
      catch ( SQLException sqlException )
      {
         sqlException.printStackTrace();
      } // end catch
    } // end method close  
}//End Class
