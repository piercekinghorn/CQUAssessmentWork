//Author; Pierce Kinghorn
//Date: 23/05/2020
package trafficproject.Model;

public class VehicleAccident {
    
    private int Accident;
    private String Vehicle;
    
    public VehicleAccident(){
        
    }
    
    public VehicleAccident(int accident, String vehicle)
    {
        setAccident(accident);
        setVehicle(vehicle);
    }
        
    //Get and set methods
    public int getAccident()
    {
        return Accident;
    }
    
    public void setAccident(int accident)
    {
        Accident = accident;
    }
    
    public String getVehicle()
    {
        return Vehicle;
    }
    
    public void setVehicle(String vehicle)
    {
        Vehicle = vehicle;
    }  
}//End Class
