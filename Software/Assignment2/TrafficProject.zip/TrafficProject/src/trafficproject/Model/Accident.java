//Author; Pierce Kinghorn
//Date: 23/05/2020
package trafficproject.Model;

import java.util.Date;

public class Accident {
    
    private String Id;
    private String Location;
    private String Comments;
    private Date Date;
    
    public Accident(){
        
    }
   
    public Accident(String id, String location, String comments, Date date)
    {
        setId(id);
        setLocation(location);
        setComments(comments);
        setDate(date);
    }
    
    //Get and set methods
    public String getId()
    {
        return Id;
    }
    
    public void setId(String id){
        Id = id;
    }
    
    public String getLocation()
    {
        return Location;
    }
    
    public void setLocation(String location){
        Location = location;
    }
    
    public String getComments()
    {
        return Comments;
    }
    
    public void setComments(String comments){
        Comments = comments;
    }
    
    public Date getDate(){
        return Date;
    }
    
    public void setDate(Date date)
    {
        Date = date;
    }    
}//End Class

