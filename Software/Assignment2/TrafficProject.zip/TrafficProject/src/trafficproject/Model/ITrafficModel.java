//Author; Pierce Kinghorn
//Date: 23/05/2020
package trafficproject.Model;

import java.util.List;

public interface ITrafficModel {
    
    public List<Accident> getAllAccidents();
    public List<Accident> searchAccidentById(int accidentId);
    public int addAccident(String location,String comments);
    public int updateAccident(String location,String comments, String accidentId);
    
    public List<Vehicle> getAllVehicles();
    public List<Vehicle> searchByVehicleId(String vehicle_id);
    public List<Vehicle> searchByOwnerName(String owner_name);
    public int addVehicle(String vehicle_name, String vehicle_model, String make_year, String owner_name, String address, String phone);
    public int updateVehicle(String vehicle_name, String vehicle_model, String make_year, String owner_name, String address, String phone);
    
    public int addVehicleAccident(String vehicle_id, String accident_id);
    public List<VehicleAccident> getAllVehicleAccidents();
    public List<VehicleAccident> getAllVehicleAccidentsByVID(String vehicle_id);

    public void close();
    
}//End Interface
