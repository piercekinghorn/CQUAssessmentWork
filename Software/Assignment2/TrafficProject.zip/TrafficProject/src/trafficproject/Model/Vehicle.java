//Author; Pierce Kinghorn
//Date: 23/05/2020
package trafficproject.Model;

public class Vehicle {
    
    private String Id;
    private String Model;
    private int Year;
    private String OwnerName;
    private String OwnerAddress;
    private int OwnerContact;
    
    public Vehicle(){
        
    }
    
    public Vehicle(String id, String model, int year,
            String ownername, String owneraddress, int ownercontact)
    {
        setId(id);
        setModel(model);
        setYear(year);
        setOwnerName(ownername);
        setOwnerAddress(owneraddress);
        setOwnerContact(ownercontact);
    }
    
    //Get and set Methods
    public String getId()
    {
        return Id;
    }
    
    public void setId(String id){
        Id = id;
    }
    
    public String getModel()
    {
        return Model;
    }
    
    public void setModel(String model){
        Model = model;
    }
    
    public int getYear(){
        return Year;
    }
    
    public void setYear(int year){
        Year = year;
    }
    
    public String getOwnerName(){
        return OwnerName;
    }
    
    public void setOwnerName(String ownername){
        OwnerName = ownername;
    }
    
    public String getOwnerAddress(){
        return OwnerAddress;
    }
    
    public void setOwnerAddress(String ownerAddress){
        OwnerAddress = ownerAddress;
    }
    
    public int getOwnerContact(){
        return OwnerContact;
    }
    
    public void setOwnerContact(int ownercontact) {
        OwnerContact = ownercontact;
    }
}//End Class
