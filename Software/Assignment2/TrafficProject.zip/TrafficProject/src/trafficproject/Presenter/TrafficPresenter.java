//Author; Pierce Kinghorn
//Date: 23/05/2020
package trafficproject.Presenter;

import trafficproject.View.ITrafficView;
import trafficproject.Model.Accident;
import trafficproject.Model.Vehicle;
import trafficproject.Model.VehicleAccident;
import java.util.List;
import trafficproject.Model.ITrafficModel;

public class TrafficPresenter {
    
    ITrafficView view;
    ITrafficModel model;
    List <Accident> accidentResults;
    int currentAccidentEntryIndex;
    int numberOfAccidentEntries;
    List <Vehicle> vehicleResults;
    int currentVehicleEntryIndex;
    int numberOfVehicleEntries;
    List <VehicleAccident> vehicleAccidentResults;
    int currentVehicleAccidentEntryIndex;
    int numberOfVehicleAccidentEntries;

    Accident currentAccidentEntry;
    Vehicle currentVehicleEntry;
    VehicleAccident currentVehicleAccidentEntry;
    
    public TrafficPresenter(ITrafficView itv, ITrafficModel tm){
        view = itv;
        model = tm;
        
        currentAccidentEntryIndex = 0;
        numberOfAccidentEntries = 0;
        accidentResults = null;
        currentAccidentEntry = null;
        
        currentVehicleEntryIndex = 0;
        numberOfVehicleEntries = 0;
        vehicleResults = null;
        currentVehicleEntry = null;
    }
    
    //Accident Methods
    public void insertNewAccidentEntry(String location,String comments) {
      
        int result = model.addAccident(location, comments);

        if ( result == 1 )
            view.displayMessage("Accident added");
        else
            view.displayMessage("Accident not added");
    }
    
    public void updateAccidentEntry(String location,String comments, String accidentId) {
      
        int result = model.updateAccident(location, comments, accidentId);

        if ( result == 1 )
            view.displayMessage("Accident updated");
         else
             view.displayMessage("Accident not updated");
    }
    
    public void displayAllAccidentEntries() {
        try 
        {
            accidentResults = model.getAllAccidents();
            view.clearAccidentQuery();
            
            numberOfAccidentEntries = accidentResults.size();
            populateAccidentDisplayQuery();
    
            if(numberOfAccidentEntries ==0)
                view.displayMessage("No records to browse");
            if ( numberOfAccidentEntries != 0 ) 
            {
                currentAccidentEntryIndex = 0;
                currentAccidentEntry = accidentResults.get( currentAccidentEntryIndex );
                populateAllAccidentTextFields();
                view.setAccidentBrowsing(true);
            }
        }
        catch ( Exception e ) {
            e.printStackTrace();
        }
    }
    
    public void displayAccidentById(int accidentId){
        try 
        {
            accidentResults = model.searchAccidentById(accidentId);
            view.clearAccidentQuery();
            
            numberOfAccidentEntries = accidentResults.size();
            populateAccidentDisplayQuery();
            if(numberOfAccidentEntries ==0)
                view.displayMessage("No records to browse");
            if ( numberOfAccidentEntries != 0 ) 
            {
                currentAccidentEntryIndex = 0;
                currentAccidentEntry = accidentResults.get( currentAccidentEntryIndex );
                populateAllAccidentTextFields();
                
                view.setAccidentBrowsing(true);
            }
        }
        catch ( Exception e ) {
            e.printStackTrace();
        }
    }
    
    private void populateAllAccidentTextFields() 
    {  
        view.displayAccidentRecord(currentAccidentEntry);  
    }
    
    public void showPreviousAccident() {   
        currentAccidentEntryIndex--;
        // wrap around
        if ( currentAccidentEntryIndex < 0 )
        
            currentAccidentEntryIndex = numberOfAccidentEntries - 1;
            currentAccidentEntry = accidentResults.get( currentAccidentEntryIndex );
            populateAllAccidentTextFields();
   }

    public void showNextAccident() {

        currentAccidentEntryIndex++;  
        // wrap around
        if ( currentAccidentEntryIndex >= numberOfAccidentEntries )
        
            currentAccidentEntryIndex = 0;
            currentAccidentEntry = accidentResults.get( currentAccidentEntryIndex );
            populateAllAccidentTextFields();
   }
    
   public void populateAccidentDisplayQuery()
   { 
        while(currentAccidentEntryIndex < numberOfAccidentEntries){
           currentAccidentEntry = accidentResults.get( currentAccidentEntryIndex );
           view.refreshAccidentQuery(currentAccidentEntry);
           currentAccidentEntryIndex ++;
        }
   }
   
   //Vehicle Methods
    public void insertNewVehicleEntry(String vehicle_id, String vehicle_model, String make_year, String owner_name, String address, String phone) {

        int result = model.addVehicle(vehicle_id, vehicle_model , make_year, owner_name, address, phone);

        if ( result == 1 )
            view.displayMessage("Vehicle added");
        else
            view.displayMessage("Vehicle not added");
    }
    
    public void updateVehicleEntry(String vehicle_id, String vehicle_model, String make_year, String owner_name, String address, String phone) {
      
       int result = model.updateVehicle(vehicle_id, vehicle_model , make_year, owner_name, address, phone);

        if ( result == 1 )
            view.displayMessage("Vehicle updated");
        else
            view.displayMessage("Vehicle not updated");
    }
    
    public void displayAllVehiclesEntries() {
        try 
        {
            vehicleResults = model.getAllVehicles();
            view.clearVehicleQuery();
         
            numberOfVehicleEntries = vehicleResults.size();
            if(numberOfVehicleEntries ==0)
                view.displayMessage("No records to browse");
            if ( numberOfVehicleEntries != 0 ) 
            {
                currentVehicleEntryIndex = 0;
                currentVehicleEntry = vehicleResults.get( currentVehicleEntryIndex );
                populateAllVehicleTextFields();
                currentVehicleEntryIndex = 0;
                populateVehicleDisplayQuery();
                view.setVehicleBrowsing(true);
            } 
        }
        catch ( Exception e ) {
            e.printStackTrace();
        }
    }
    
    public void displayVehicleById(String vehicle_id){
        try 
        {
            vehicleResults = model.searchByVehicleId(vehicle_id);
            view.clearVehicleQuery();
            numberOfVehicleEntries = vehicleResults.size();
            if(numberOfVehicleEntries ==0)
                view.displayMessage("No records to browse");
            if ( numberOfVehicleEntries != 0 ) 
            {
                currentVehicleEntryIndex = 0;
                currentVehicleEntry = vehicleResults.get( currentVehicleEntryIndex );
                populateAllVehicleTextFields();
                currentVehicleEntryIndex = 0;
                populateVehicleDisplayQuery();
                view.setVehicleBrowsing(true);
            } 
        }
        catch ( Exception e ) {
            e.printStackTrace();
        }
    }
    
    public void displayVehicleByOwnerName(String owner_name){
        try 
        {
            vehicleResults = model.searchByOwnerName(owner_name);
            view.clearVehicleQuery();
            numberOfVehicleEntries = vehicleResults.size();
            if(numberOfVehicleEntries ==0)
                view.displayMessage("No records to browse");
            if ( numberOfVehicleEntries != 0 ) 
            {
                currentVehicleEntryIndex = 0;
                currentVehicleEntry = vehicleResults.get( currentVehicleEntryIndex );
                populateAllVehicleTextFields();
                currentVehicleEntryIndex = 0;
                populateVehicleDisplayQuery();
                view.setVehicleBrowsing(true);
            } 
        }
        catch ( Exception e ) {
            e.printStackTrace();
        }
    }
    
    private void populateAllVehicleTextFields() 
    {
        view.displayVehicleRecord(currentVehicleEntry);
    }
    
    public void showPreviousVehicle() {   
        currentVehicleEntryIndex--;
        // wrap around
        if ( currentVehicleEntryIndex < 0 )
            currentVehicleEntryIndex = numberOfVehicleEntries - 1;
            currentVehicleEntry = vehicleResults.get( currentVehicleEntryIndex );
            populateAllVehicleTextFields();
   }

    public void showNextVehicle() {
        System.out.println(currentVehicleEntryIndex + "HERE");
        currentVehicleEntryIndex++;
        // wrap around
        if ( currentVehicleEntryIndex >= numberOfVehicleEntries )
            currentVehicleEntryIndex = 0;
            currentVehicleEntry = vehicleResults.get( currentVehicleEntryIndex );
     
            populateAllVehicleTextFields(); 
   }
    
    public void populateVehicleDisplayQuery()
    { 
        while(currentVehicleEntryIndex < numberOfVehicleEntries){
           currentVehicleEntry = vehicleResults.get( currentVehicleEntryIndex );
           view.refreshVehicleQuery(currentVehicleEntry);
           currentVehicleEntryIndex ++;
        }
    }
    
    //Vehicle Accident Methods
    public void insertNewVehicleAccidentEntry(String vehicle_id, String accident_id) {

        int result = model.addVehicleAccident(vehicle_id, accident_id);

        if ( result == 1 )
            view.displayMessage("Vehicle accident saved");
        else
            view.displayMessage("Vehicle accident not saved");
    }
    
    public void displayAllVehiclesAccidentEntries()
    {
        try 
        {
            vehicleAccidentResults = model.getAllVehicleAccidents();
            view.clearVehicleAccidentQuery();
            numberOfVehicleAccidentEntries = vehicleAccidentResults.size();
            if(numberOfVehicleAccidentEntries ==0)
                view.displayMessage("No records to browse");
            if ( numberOfVehicleAccidentEntries != 0 ) 
            {
                currentVehicleAccidentEntryIndex = 0;
                currentVehicleAccidentEntry = vehicleAccidentResults.get( currentVehicleAccidentEntryIndex );
                populateVehicleAccidentDisplayQuery();
                currentVehicleAccidentEntryIndex = 0;
            }
        }
        catch ( Exception e ) {
            e.printStackTrace();
        }
    }
    
    public void searchByVID(String vehicle_id)
    {
        try 
        {
            vehicleAccidentResults = model.getAllVehicleAccidentsByVID(vehicle_id);
            view.clearVehicleAccidentQuery();
         
            numberOfVehicleAccidentEntries = vehicleAccidentResults.size();
            
            if(numberOfVehicleAccidentEntries ==0)
                view.displayMessage("No records to browse");
            if ( numberOfVehicleAccidentEntries != 0 ) 
            {
                currentVehicleAccidentEntryIndex = 0;
                populateVehicleAccidentDisplayQuery();  
            }
        }
        catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    public void populateVehicleAccidentDisplayQuery()      
    { 
        currentVehicleAccidentEntry = vehicleAccidentResults.get( currentVehicleAccidentEntryIndex );
        
        while(currentVehicleAccidentEntryIndex < numberOfVehicleAccidentEntries){
           currentVehicleAccidentEntry = vehicleAccidentResults.get( currentVehicleAccidentEntryIndex );
           view.refreshVehicleAccidentQuery(currentVehicleAccidentEntry);
           currentVehicleAccidentEntryIndex ++;
        }
    }
    //General Methods
    public void close() {
      model.close();
    }
    
}//End Class
