//Author; Pierce Kinghorn
//Date: 23/05/2020
package trafficproject.View;

import trafficproject.Model.Accident;
import trafficproject.Model.Vehicle;
import trafficproject.Model.VehicleAccident;
import trafficproject.Presenter.TrafficPresenter;


public interface ITrafficView {
    void setAccidentBrowsing(Boolean f);
    void setVehicleBrowsing(Boolean f);
    void displayAccidentRecord(Accident a);
    void displayVehicleRecord(Vehicle v);
    void displayMessage(String m); 
    void bind(TrafficPresenter p);
    void refreshAccidentQuery(Accident a);
    void refreshVehicleQuery(Vehicle v);
    void refreshVehicleAccidentQuery(VehicleAccident va);
    void clearAccidentQuery();
    void clearVehicleQuery();
    void clearVehicleAccidentQuery();
}//End Class
