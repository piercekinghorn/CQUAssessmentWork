//Author; Pierce Kinghorn
//Date: 23/05/2020
package trafficproject.View;

import trafficproject.Presenter.TrafficPresenter;
import trafficproject.Model.Accident;
import trafficproject.Model.Vehicle;
import trafficproject.Model.VehicleAccident;
import trafficproject.View.ITrafficView;
import java.awt.FlowLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;

public class TrafficView extends JFrame implements ITrafficView{
    
    private TrafficPresenter presenter;
    
    //Accident Components
 
    private JLabel accidentIdLabel;
    private JTextField accidentIdField;
    private JLabel accidentDateLabel;
    private JTextField accidentDateField;    
    private JLabel locationLabel;
    private JTextField locationField;
    private JLabel commentsLabel;
    private JTextField commentsField;
    
    private JPanel addAccidentPanel;
    private JPanel displayAccidentPanel;
    private JScrollPane accidentScroll;
    
    private JTextArea displayAccidentQuery;
    private JTextField searchByAccidentIdTextField;
  
    private JButton displayAllAccidents;
    private JButton searchByAccidentId;
    private JButton addAccidentButton;
    private JButton nextAccidentButton;
    private JButton updateAccidentButton;
    private JButton previousAccidentButton;
    
    //Vehicle Components
    private JLabel vehicleIdLabel;
    private JTextField vehicleIdTextField;
    private JLabel vehicleModelLabel;
    private JTextField vehicleModelTextField;
    private JLabel vehicleYearLabel;
    private JTextField vehicleYearTextField;
    private JLabel vehicleOwnerNamelabel;
    private JTextField vehicleOwnerNameTextField;
    private JLabel vehicleOwnerAddressLabel;
    private JTextField vehicleOwnerAddressTextField;
    private JLabel vehicleOwnerContactLabel;
    private JTextField vehicleOwnerContactTextField;
    
    private JPanel addVehiclePanel;
    private JPanel displayVehiclePanel;
    private JScrollPane vehicleScroll;
    
    private JTextArea displayVehicleQuery;
    private JTextField searchByTextField;
     
    private JButton displayAllVehicles;
    private JButton searchByVehicleIdButton;
    private JButton searchByVehicleNameButton;
    private JButton addVehicleButton;
    private JButton nextVehicleButton;
    private JButton updateVehicleButton;
    private JButton previousVehicleButton;
    private JButton checkVehicleId;
    
    //Vehicle Accident Componenents
    private JPanel addPanel;
    private JButton createVehicleAccident;
    private JButton displayAllVehicleAccidents;
    private JTextArea vehicleAccidentArea;
    private JLabel invisLabel;
    private JTextField searchByVIDTextField;
    private JButton searchByVIDButton;

    public TrafficView()
    {
        super( "Traffic Project " );
        
        // create GUI
        //Accident Components
        accidentIdLabel = new JLabel();
        accidentIdField = new JTextField(10);
        accidentDateLabel = new JLabel();
        accidentDateField = new JTextField(10);
        locationLabel = new JLabel();
        locationField = new JTextField(10);
        commentsLabel = new JLabel();
        commentsField = new JTextField(10);

        addAccidentPanel = new JPanel();
        displayAccidentPanel = new JPanel();
        accidentScroll = new JScrollPane();
        
        displayAccidentQuery = new JTextArea();  
        displayAccidentQuery.setPreferredSize(new Dimension(250,250));
        searchByAccidentIdTextField = new JTextField(10);
        searchByAccidentIdTextField.setPreferredSize(new Dimension(15,30));
        
        displayAllAccidents = new JButton();
        displayAllAccidents.setPreferredSize(new Dimension(15,30));
        updateAccidentButton = new JButton();
        searchByAccidentId = new JButton();
        searchByAccidentId.setPreferredSize(new Dimension(15,30));
        addAccidentButton = new JButton();
        previousAccidentButton = new JButton();
        nextAccidentButton = new JButton();
        
        //Vehicle Components
        vehicleIdLabel = new JLabel();
        vehicleIdTextField = new JTextField(10);
        vehicleModelLabel = new JLabel();
        vehicleModelTextField = new JTextField(10);
        vehicleYearLabel = new JLabel();
        vehicleYearTextField = new JTextField(10);
        vehicleOwnerNamelabel = new JLabel();
        vehicleOwnerNameTextField = new JTextField(10);
        vehicleOwnerAddressLabel = new JLabel();
        vehicleOwnerAddressTextField = new JTextField(10);
        vehicleOwnerContactLabel = new JLabel();
        vehicleOwnerContactTextField = new JTextField(10);
    
        addVehiclePanel = new JPanel();
        displayVehiclePanel = new JPanel();
        vehicleScroll = new JScrollPane();
        
        displayVehicleQuery = new JTextArea();
        searchByTextField = new JTextField();
     
        displayAllVehicles = new JButton();
        addVehicleButton = new JButton();
        nextVehicleButton = new JButton();
        updateVehicleButton = new JButton();
        previousVehicleButton = new JButton();
        checkVehicleId = new JButton();
        searchByVehicleIdButton = new JButton();
        searchByVehicleNameButton = new JButton();
        
        //Vehicle Accident Components
        addPanel = new JPanel();
        createVehicleAccident = new JButton();
        displayAllVehicleAccidents = new JButton();
        vehicleAccidentArea = new JTextArea();
        searchByVIDTextField = new JTextField(10);
        searchByVIDButton = new JButton();
        invisLabel = new JLabel();
        invisLabel.setVisible(false);
        
        //setLayout(new GridLayout(4,2,10,10));
        setLayout(new FlowLayout(FlowLayout.LEFT,20,20));
        setSize( 1500, 1000 );
        setResizable( false );

        //Add Accident Panel Start
        addAccidentPanel.setLayout( new GridLayout( 9, 2, 10, 10 ) );
        addAccidentPanel.setPreferredSize(new Dimension(300,500));
       
        accidentIdLabel.setText("Accident ID");
        addAccidentPanel.add(accidentIdLabel);
        accidentIdField.setEditable(false);
        addAccidentPanel.add(accidentIdField);
        
        accidentDateLabel.setText("Accident Date");
        addAccidentPanel.add(accidentDateLabel);
        accidentDateField.setEditable(false);
        addAccidentPanel.add(accidentDateField);
        
        locationLabel.setText( "Location" );
        addAccidentPanel.add(locationLabel);
        addAccidentPanel.add(locationField);
        
        commentsLabel.setText( "Comments" );
        addAccidentPanel.add(commentsLabel);
        addAccidentPanel.add(commentsField);
        
        addAccidentButton.setText("Add Accident");
        addAccidentButton.addActionListener
            (new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    addAccidentButtonActionPerformed(e );
                }
            }
        );
        addAccidentPanel.add(addAccidentButton );
        
        updateAccidentButton.setText("Update Accident");
        updateAccidentButton.addActionListener(
            new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    updateAccidentButtonActionPerformed(e);
            }
        }
        );
        addAccidentPanel.add(updateAccidentButton);
        
        previousAccidentButton.setText("Previous Accident");
        previousAccidentButton.setEnabled(false);
        previousAccidentButton.addActionListener
            (new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    previousAccidentButtonActionPerfromed(e);
                }
            }
        );
        addAccidentPanel.add(previousAccidentButton);
        
        nextAccidentButton.setText("Next Accident");
        nextAccidentButton.setEnabled(false);
        nextAccidentButton.addActionListener
            (new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    nextAccidentButtonActionPerfromed(e);
                }
            }
        );
        addAccidentPanel.add(nextAccidentButton);
        add(addAccidentPanel );
        //Add Accident Panel End
        
        //Display Accident Panel Start
        displayAccidentQuery.isVisible();
        displayAccidentQuery.setEditable(false);
        JScrollPane scroll = new JScrollPane(displayAccidentQuery,
            JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        displayAccidentPanel.add(scroll);
     
        displayAccidentPanel.setLayout(new GridLayout(9,1,10,10));
        displayAccidentPanel.setPreferredSize(new Dimension(400,500));
        
        displayAllAccidents.setText("Show all accidents");
        displayAllAccidents.setSize(40, 5);
        displayAllAccidents.addActionListener
            (new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    displayAllAccidentsButtonActionPerformed(e );
                }
            }
        );
        displayAccidentPanel.add(displayAllAccidents);
        
        displayAccidentPanel.add(searchByAccidentIdTextField);
        
        searchByAccidentId.setText("Search accidents by Id");
        searchByAccidentId.setSize(40,5);
        searchByAccidentId.addActionListener
            (new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    searchByAccidentIdButtonActionPerformed(e );
                }
            }
        );

        displayAccidentPanel.add(searchByAccidentId);
        
        add(displayAccidentPanel);
        //Display Accident Panel End
        
        //Add Vehicle Panel Start
        addVehiclePanel.setLayout( new GridLayout(9,2,10,10));
        addVehiclePanel.setPreferredSize(new Dimension(300,500));
        
        vehicleIdLabel.setText("Vehicle Id");
        addVehiclePanel.add(vehicleIdLabel);
        addVehiclePanel.add(vehicleIdTextField);
        
        vehicleModelLabel.setText("Vehicle Model");
        addVehiclePanel.add(vehicleModelLabel);
        addVehiclePanel.add(vehicleModelTextField);
        
        vehicleYearLabel.setText("Year Built");
        addVehiclePanel.add(vehicleYearLabel);
        addVehiclePanel.add(vehicleYearTextField);
        
        vehicleOwnerNamelabel.setText("Owner Name");
        addVehiclePanel.add(vehicleOwnerNamelabel);
        addVehiclePanel.add(vehicleOwnerNameTextField);
        
        vehicleOwnerAddressLabel.setText("Owner Address");
        addVehiclePanel.add(vehicleOwnerAddressLabel);
        addVehiclePanel.add(vehicleOwnerAddressTextField);
        
        vehicleOwnerContactLabel.setText("Owner Phone");
        addVehiclePanel.add(vehicleOwnerContactLabel);
        addVehiclePanel.add(vehicleOwnerContactTextField);
        
        addVehicleButton.setText("Add Vehicle");
        addVehicleButton.addActionListener
        (new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    addVehicleButtonActionPerformed(e);
                }
            }
        );
        addVehiclePanel.add(addVehicleButton);
        
        updateVehicleButton.setText("Update Vehicle");
        updateVehicleButton.addActionListener
        (new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    updateVehicleButtonActionPerformed(e);
                }
            }
        );
        addVehiclePanel.add(updateVehicleButton);
        
        previousVehicleButton.setText("Previous Vehicle");
        previousVehicleButton.setEnabled(false);
        previousVehicleButton.addActionListener
        (new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    previousVehicleButtonActionPerfromed(e);
                }
            }
        );
        addVehiclePanel.add(previousVehicleButton);
                
        nextVehicleButton.setText("Next Vehicle");
        nextVehicleButton.setEnabled(false);
        nextVehicleButton.addActionListener
        (new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    nextVehicleButtonActionPerfromed(e);
                }
            }
        );
        addVehiclePanel.add(nextVehicleButton);
        
        add(addVehiclePanel);
        //Add Vehicle Panel End
        
        //Display Vehicle Panel Start
        displayVehicleQuery.isVisible();
        displayVehicleQuery.setEditable(false);
        JScrollPane vehiclescroll = new JScrollPane(displayVehicleQuery,
            JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        displayVehiclePanel.add(vehiclescroll);
     
        displayVehiclePanel.setLayout(new GridLayout(9,1,10,10));
        displayVehiclePanel.setPreferredSize(new Dimension(400,500));

        displayAllVehicles.setText("Show all vehicles");
        displayAllVehicles.setSize(40, 5);
        displayAllVehicles.addActionListener
            (new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    displayAllVehiclesButtonActionPerformed(e);
                }
            }
        );
        displayVehiclePanel.add(displayAllVehicles);
        
        displayVehiclePanel.add(searchByTextField);
        
        searchByVehicleIdButton.setText("Search vehicles by Id");
        searchByVehicleIdButton.setSize(40,5);
        searchByVehicleIdButton.addActionListener
            (new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    searchByVehicleIdButtonActionPerformed(e);
                }
            }
        );
        displayVehiclePanel.add(searchByVehicleIdButton);
        
        searchByVehicleNameButton.setText("Search vehicles by Ownername");
        searchByVehicleNameButton.setSize(40,5);
        searchByVehicleNameButton.addActionListener
        (new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    searchByOwnernameButtonActionPerformed(e);
                }
            }
        );
        displayVehiclePanel.add(searchByVehicleNameButton);
                
        add(displayVehiclePanel);
        //Display Vehicle Panel End
        
        //Vehicle Accident Panel Start
        addPanel.setLayout( new GridLayout(9,2,10,10));
        addPanel.setPreferredSize(new Dimension(400,500)); 
        
        vehicleAccidentArea.isVisible();
        vehicleAccidentArea.setEditable(false);
        JScrollPane VAScroll = new JScrollPane(vehicleAccidentArea,
            JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        addPanel.add(VAScroll);
        
        createVehicleAccident.setText("Create Vehicle Accident Entry");
        //createVehicleAccident.setEnabled(false);
        createVehicleAccident.setSize(40,5);
        createVehicleAccident.addActionListener
        (new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    addVehicleAccidentButtonActionPerformed(e);
                }
            }
        );
        addPanel.add(createVehicleAccident);
        
        displayAllVehicleAccidents.setText("Display Vehicle Accident Entries");
        displayAllVehicleAccidents.setSize(40,5);
        displayAllVehicleAccidents.addActionListener
        (new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    displayAllVehicleAccidentsButtonActionPerformed(e);
                }
            }
        );
        addPanel.add(displayAllVehicleAccidents);
        addPanel.add(searchByVIDTextField);
        searchByVIDButton.setText("Search By Vehicle Id");
        searchByVIDButton.addActionListener
        (new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    searchByVIDButtonActionPerformed(e);
                }
            }
        );
        addPanel.add(searchByVIDButton);
        addPanel.add(invisLabel);
        
        add(addPanel);
        //Vehicle Accident Panel End
       
        addWindowListener( 
        new WindowAdapter() 
        {  
            public void windowClosing( WindowEvent evt )
            {
               presenter.close();
               System.exit( 0 );
            } // end method windowClosing
        } // end anonymous inner class
        ); // end call to addWindowListener
	
        setVisible( true );
    }
    
    //Add Accident methods
    private void addAccidentButtonActionPerformed( ActionEvent evt ) 
    {
        String location=locationField.getText();
        String comments=commentsField.getText();
        presenter.insertNewAccidentEntry(location, comments);
    } 
    
    private void updateAccidentButtonActionPerformed(ActionEvent evt)
    {
        String location=locationField.getText();
        String comments=commentsField.getText();
        String accidentId =accidentIdField.getText();
        presenter.updateAccidentEntry(location, comments, accidentId);
    }
    
    private void previousAccidentButtonActionPerfromed( ActionEvent evt ) 
    {
        presenter.showPreviousAccident();
    } 
    
    private void nextAccidentButtonActionPerfromed( ActionEvent evt ) 
    {
        presenter.showNextAccident();
    }
    
    private void displayAllAccidentsButtonActionPerformed( ActionEvent evt ) 
    {
        presenter.displayAllAccidentEntries();
    } 
    
    private void searchByAccidentIdButtonActionPerformed( ActionEvent evt)
    {
        if(searchByAccidentIdTextField.getText().equals(""))
        {
            displayMessage("No search filter applied");
        }
        else
        {
            presenter.displayAccidentById(Integer.parseInt(searchByAccidentIdTextField.getText()));    
        }
    }
    
    @Override
    public void displayAccidentRecord(Accident a)
    {
        accidentIdField.setText(""+a.getId());
        locationField.setText(""+ a.getLocation() );
        commentsField.setText(""+ a.getComments() );
        accidentDateField.setText(""+a.getDate() ); 
    }
    
    @Override
    public void setAccidentBrowsing(Boolean f)
    {
        previousAccidentButton.setEnabled(f);
        nextAccidentButton.setEnabled(f);
    }

    @Override
    public void clearAccidentQuery()
    {
        displayAccidentQuery.setText("");
    }
    
    @Override
    public void refreshAccidentQuery(Accident a)
    {
        displayAccidentQuery.append(""+a.getId()+"   ");
        displayAccidentQuery.append(""+a.getLocation()+"   ");
        displayAccidentQuery.append(""+ a.getComments()+"  ");
        displayAccidentQuery.append(""+a.getDate()+"\n"); 
    }
    
    //Add Vehicle Methods
    private void addVehicleButtonActionPerformed( ActionEvent evt ) 
    {
        String vehicle_id=vehicleIdTextField.getText();
        String vehicle_model=vehicleModelTextField.getText();
        String make_year=vehicleYearTextField.getText();
        String owner_name=vehicleOwnerNameTextField.getText();
        String address=vehicleOwnerAddressTextField.getText();
        String phone=vehicleOwnerContactTextField.getText();
        presenter.insertNewVehicleEntry(vehicle_id, vehicle_model, make_year, owner_name, address, phone);
    } 
    
    private void updateVehicleButtonActionPerformed(ActionEvent evt)
    {
        String vehicle_id=vehicleIdTextField.getText();
        String vehicle_model=vehicleModelTextField.getText();
        String make_year=vehicleYearTextField.getText();
        String owner_name=vehicleOwnerNameTextField.getText();
        String address=vehicleOwnerAddressTextField.getText();
        String phone=vehicleOwnerContactTextField.getText();
        presenter.updateVehicleEntry(vehicle_id, vehicle_model, make_year, owner_name, address, phone);
    }
    
    private void searchByVehicleIdButtonActionPerformed( ActionEvent evt)
    {
        if(searchByTextField.getText().equals(""))
        {
            displayMessage("No search filter applied");
        }
        else
        {
            presenter.displayVehicleById(searchByTextField.getText());    
        }
    }
        
    private void searchByOwnernameButtonActionPerformed( ActionEvent evt)
    {
        if(searchByTextField.getText().equals(""))
        {
            displayMessage("No search filter applied");
        }
        else
        {
            presenter.displayVehicleByOwnerName(searchByTextField.getText());    
        }
    }
    
    private void displayAllVehiclesButtonActionPerformed( ActionEvent evt ) 
    {
        presenter.displayAllVehiclesEntries();
    }
    
    private void previousVehicleButtonActionPerfromed( ActionEvent evt ) 
    {
        presenter.showPreviousVehicle();
    } 
    
    private void nextVehicleButtonActionPerfromed( ActionEvent evt ) 
    {
        presenter.showNextVehicle();
    }
    
    @Override
    public void displayVehicleRecord(Vehicle v)
    {
        vehicleIdTextField.setText(""+v.getId());
        vehicleModelTextField.setText(""+ v.getModel() );
        vehicleYearTextField.setText(""+ v.getYear() );
        vehicleOwnerNameTextField.setText(""+v.getOwnerName() );
        vehicleOwnerAddressTextField.setText(""+v.getOwnerAddress() ); 
        vehicleOwnerContactTextField.setText(""+v.getOwnerContact() );  
    }
    
    @Override
    public void setVehicleBrowsing(Boolean f)
    {
        previousVehicleButton.setEnabled(f);
        nextVehicleButton.setEnabled(f);
    }

    @Override
    public void clearVehicleQuery()
    {
        displayVehicleQuery.setText("");
    }
    
    @Override
    public void refreshVehicleQuery(Vehicle v)
    {
        displayVehicleQuery.append(""+v.getId()+"  ");
        displayVehicleQuery.append(""+ v.getModel()+"  ");
        displayVehicleQuery.append(""+ v.getYear()+"  ");
        displayVehicleQuery.append(""+v.getOwnerName()+"  ");
        displayVehicleQuery.append(""+v.getOwnerAddress()+"  "); 
        displayVehicleQuery.append(""+v.getOwnerContact()+"\n"); 
    }
    
    //Vehicle Accident Methods
    public void addVehicleAccidentButtonActionPerformed(ActionEvent event)
    {
        if( vehicleIdTextField.getText().equals("") && accidentIdField.getText().equals(""))
        {
            displayMessage("Select both a vehicle and accident");
        }
        else if(vehicleIdTextField.getText().equals(""))
        {
            displayMessage("Select a vehicle");
        }
        else if(accidentIdField.getText().equals(""))
        {
            displayMessage("Select an accident");
        }
        else
        {
            String vehicle_id=vehicleIdTextField.getText();
            String accident_id=accidentIdField.getText();
            presenter.insertNewVehicleAccidentEntry(vehicle_id, accident_id);
        }
    }
    
    private void searchByVIDButtonActionPerformed(ActionEvent evt)
    {
        invisLabel.setText(" ");
        presenter.searchByVID(searchByVIDTextField.getText());
    }
    
    private void displayAllVehicleAccidentsButtonActionPerformed( ActionEvent evt ) 
    {
        invisLabel.setText(" ");
        presenter.displayAllVehiclesAccidentEntries();
    }
    
    @Override
    public void refreshVehicleAccidentQuery(VehicleAccident va)
    {
        if(invisLabel.getText().equals(Integer.toString(va.getAccident())))
        {
            vehicleAccidentArea.append(""+va.getVehicle()+"  ");
        }
        else
        {
            vehicleAccidentArea.append("\n"+va.getAccident()+"   ");
            vehicleAccidentArea.append(""+va.getVehicle()+"  ");
        }
        invisLabel.setText(Integer.toString(va.getAccident()));             
    }
    
    @Override
    public void clearVehicleAccidentQuery()
    {
        vehicleAccidentArea.setText("");
    }
    
    //General Methods
    @Override
    public void displayMessage(String m)
    {
        JOptionPane.showMessageDialog( this,m );
    }
    
    @Override
    public void bind( TrafficPresenter tp) 
    {
       presenter = tp;
    }
}//End Class
